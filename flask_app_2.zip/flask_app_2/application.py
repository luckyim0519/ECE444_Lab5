from flask import Flask, request
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import pickle
import json

application = Flask(__name__)

@application.route("/")
def index():
    return "Your Flask App Works! V1.0"
'''
@application.route("/fake_api")
def load_model():
    
    return
'''

if __name__ == "__main__":
    application.run(port=5000, debug=True)
